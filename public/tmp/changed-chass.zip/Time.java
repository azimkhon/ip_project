package iut.labs;

public class Time {

    private int hour = 0;
    private int minute = 0;
    private int second = 0;

    public Time(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int h) {
        hour = h;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int m) {
        minute = m;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int s) {
        second = s;
    }
    
    public void setTime(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }
    
    public void print(){
        System.out.printf("%02d:%02d:%02d\n", hour, minute, second);
    }
	
    public void nextSecond(){
        second++;
        if(second == 60) {
            second = 0;
            minute++;
            if(minute == 60) {
                minute = 0;
                hour++;
                if(hour == 24){
                    hour = 0;
                }
            }
        }
    }
}
