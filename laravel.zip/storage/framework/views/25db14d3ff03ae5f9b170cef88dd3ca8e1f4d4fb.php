<?php $__env->startSection('content'); ?>

<section class="section">
        <div class="container is-fluid">
            <div class="columns">
                <div class="column is-half is-offset-one-quarter">
                    <h1 class="title">Contact us</h1>
                    <form action="<?php echo e(route('contact')); ?>" method="POST" class="form">
                    	<?php echo e(csrf_field()); ?>


                    	<div class="field">
                            <?php if(Session::has('success')): ?>
                     <div class="notification is-info">
  Message was successfully sent
</div>
                        <?php endif; ?> 

                    		<label for="email" class="label">Email</label>
                    		<p class="control">
			                    <input type="email" name="email" id="email" placeholder="e.g. student@mailinha.uz" class="input<?php echo e($errors->has('email') ? ' is-danger' : ''); ?>" value="<?php echo e(old('email')); ?>">
			                </p>
						<?php if($errors->has('email')): ?>
			                <p class="help is-danger">
			                    <?php echo e($errors->first('email')); ?>

			                </p>
						<?php endif; ?>			                
                    	</div>

                    	<div class="field">
                    		<label for="subject" class="label">Subject</label>
                    		<p class="control">
                    			<input type="text" name="subject" id="subject" class="input">
                    		</p>
                    	</div>

						<div class="field">
							<label for="message" class="label">Your message</label>
							<p class="control">
								<textarea name="message" id="message" class="textarea"></textarea>
							</p>
						</div>                    	
                        <p class="control">
                            <button class="button is-info">Send message
                            </button>
                        </p>
						
                    </form>
                </div>
            </div>
        </div>
</section>                    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>