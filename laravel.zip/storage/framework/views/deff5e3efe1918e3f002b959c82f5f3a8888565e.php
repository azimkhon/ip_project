<h3>You have a new notification from contacts</h3>

<div>
	<?php echo e($bodyMessage); ?>

</div>

<p>Sent via <?php echo e($email); ?></p>