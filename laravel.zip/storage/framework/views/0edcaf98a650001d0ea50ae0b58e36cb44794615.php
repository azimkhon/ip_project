<aside class="menu">
	<p class="menu-label">MyDashboard</p>

	<ul class="menu-list">
		<li><a href="<?php echo e(route('account.files.index')); ?>">My files</a></li>
		<li><a href="<?php echo e(route('account.files.create.start')); ?>">Sell a file</a></li>
	</ul>
	<p class="menu-label">General</p>

	<ul class="menu-list">
		<li><a href="#">My details</a></li>
		<li><a href="#">Change password</a></li>
	</ul>	

</aside>