<?php $__env->startSection('account.content'); ?>
	
<h2><a href="https://connect.stripe.com/oath/authorize?response_type=code&state=abc&scope=read_write&client_id=<?php echo e(config('services.stripe_connect.key')); ?>">Connect your stripe account to work with payment system</a></h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('account.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>