<aside class="menu">
	<p class="menu-label">Manage Files</p>

	<ul class="menu-list">
		<li><a href="{{ route('admin.files.new.index') }}">Approve new files</a></li>
		<li><a href="{{ route('admin.files.updated.index') }}">Approve updated files</a></li>
	</ul>
</aside>