<section class="hero is-primary">
	<div class="hero-body">
		<div class="level">
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Total Files</p>
					<p class="title">0</p>
				</div> 
			</div>
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Total Deals</p>
					<p class="title">0</p>
				</div>
			</div>			
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Commision this month</p>
					<p class="title">UZS 0</p>
				</div>
			</div>	 
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Total comission</p>
					<p class="title">UZS 0</p>
				</div>
			</div>			
		</div>
	</div>
</section>