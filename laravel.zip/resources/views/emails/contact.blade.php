<h3>You have a new notification from contacts</h3>

<div>
	{{ $bodyMessage }}
</div>

<p>Sent via {{ $email }}</p>