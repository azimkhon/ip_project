@extends('emails.layouts.default')

@section('content')
	Your file "{{ $file->title }}" has been approved
@endsection