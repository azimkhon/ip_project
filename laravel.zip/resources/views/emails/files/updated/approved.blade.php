@extends('emails.layouts.default')

@section('content')
	UPDATES of your file "{{ $file->title }}" has been approved
@endsection