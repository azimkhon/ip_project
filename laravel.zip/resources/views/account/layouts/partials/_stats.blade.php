<section style="background-color: #c5e4ff;" class="hero">
	<div class="hero-body">
		<div class="level">
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Files</p>
					<p class="title">0</p>
				</div>
			</div>
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Deals</p>
					<p class="title">0</p>
				</div>
			</div>			
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">Deals this month</p>
					<p class="title">UZS 0</p>
				</div>
			</div>	
			<div class="level-item has-text-centered">
				<div>
					<p class="heading">All deals</p>
					<p class="title">UZS 0</p>
				</div>
			</div>			
		</div>
	</div>
</section>