@extends('account.layouts.default')

@section('account.content')
	Account home
@endsection