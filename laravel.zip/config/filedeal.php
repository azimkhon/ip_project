<?php 
/**
 * Here we implemented the percentage of our commission!
 */
return [
	'sales' => [
		'commission' => 20, 
	]
];

?>